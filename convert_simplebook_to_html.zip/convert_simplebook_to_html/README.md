# simplebook_markdown

# 2024-02-24-1

Simple markdown for converting txt to html. Converter included. 

Written in Python.

## What is it

It is a simple markdown convertor, made for converting scanned/written text to ebooks.

Each paragraph is separated by an empty line.

It will convert small set of markdown tags to html, with minimal modifications of the original text.

After that you can use pandoc/kindlegen[1]/calibre to convert it to the ebook (epub/mobi), or some other format.

.f1 Kindlegen can be found in the Kindle previewer package, unzip the installation and look for kindlegen.exe

## Reason

1. If you do not like it, then it's not for you. It is not made for programming, or math books.

It exists to solve two problems:

- not honoring newlines
- accidental rendering of text as tags. (1-2 3-4, rendered as text with a line through it.)

Or if you have a scanned book(s) you wish to convert to ebook(s), to read on your kindle.

To add more tags (tables, bold, italic, lists, code ...) use html code.

Or add custom tags in .py file.

## Installing

Download <a href="https://github.com/dbojan/simplebook_markdown/raw/refs/heads/main/convert_simplebook_to_html.zip">zip file</a> (right click, save link as), unpack.

To convert txt to html, drag and drop your .txt file on .bat file.

You must have Python installed <a href="https://www.python.org/">https://www.python.org/</a>

## Tags supported

-Each part of text separated by empty lines, will be added &lt;p> at the start of the block, and &lt;/p> at the end of the block, and be rendered as a paragraph.
To avoid this, add one space at the start of each line.

-New lines will be rendered as new lines. :)
It does not matter if text inside block is moved one space from the start, it will still be added new lines (&lt;br>)

Block tags:
-they have to be at the start of the line, followed by space, and the content:
-have to be preceded and followed by an empty line:
-<b>all text</b> will be surrounded by tag, <b>including</b> text after image.jpg, if there is any. You can add image description in the next line using ".pc description":
-If there is a line starting with space between two lines, it will be joined in a single block, and will be rendered as such, with newline (&lt;br>) between lines.

-heading tags. Aligned center by default (using included css rules).

<table border=1>  <tr><td>.i flower.png</td>     <td>&lt;img src="flower.png"></td> </tr>  <tr><td>.1 This is heading size 1</td>     <td>&lt;h1 >This is heading size 1&lt;/h1></td> </tr>  <tr><td>.2 This is heading size 2</td>     <td>&lt;h2 >This is heading size 2&lt;/h2></td> </tr>  <tr><td>.3 This is heading size 3</td>     <td>&lt;h3 >This is heading size 3&lt;/h3></td> </tr>  <tr><td>.4 This is heading size 4</td>     <td>&lt;h4 >This is heading size 4&lt;/h4></td> </tr> </table>

.i flower.png

.1 This is heading size 1

.2 This is heading size 2

.3 This is heading size 3

.4 This is heading size 4


-text with
newline

<table border=1>  <tr><td>-text with<br>newline</td>     <td>&lt;p>-text with&lt;br>newline&lt;/p></td> </tr> </table>

-Footnotes[2]

<table border=1>  <tr><td>footnotes[2]</td>     <td>footnotes&lt;sup>&lt;a id="f2" href="#fb2">&#91;2]&lt;/a>&lt;/sup></td> </tr>   <tr><td>.f2 Footnotes are ...</td>     <td>   &lt;div id="fb2">&lt;a href="#f2">2.&lt;/a> Footnotes are ...&lt;/div>&lt;/a>    </td> </tr> </table>

it supports footnotes[2], footnotes will be moved to the end of the file, this can be changed.

.f2 Footnotes are ...

-Horizontal line, with space after .*

 <table border=1>  <tr><td>.* </td> <td>&lt;hr></td></tr></table>

.* 

-Table of contents (toc).
Make sure to add '.t ' (with space after t) at the location you want to place your toc.
Toc is created from headings (1-4) tags, with toc entry ID added automatically.


<table border=1>  <tr><td>.t </td>  <td> &lt;div>&lt;a href="#toc1">- simplebook_markdown&lt;/a>&lt;/div><br> &lt;div>&lt;a href="#toc2">- What is it&lt;/a>&lt;/div> <br> &lt;div>&lt;a href="#toc3">- Reason&lt;/a>&lt;/div> <br> &lt;div>&lt;a href="#toc4">- Tags supported&lt;/a>&lt;/div> <br> &lt;div>&lt;a href="#toc5">- This is heading size 1&lt;/a>&lt;/div> </td>  </tr> </table> 

.t 

## Custom block tags, enabled by default

Heading tags, which do the same as above, size 1-4:

<table border=1>  <tr><td># This is heading size 1</td> <td>&lt;h1 >This is heading size 1&lt;/h1></td> </tr>  <tr><td>## This is heading size 2</td> <td>&lt;h2 >This is heading size 2&lt;/h2></td> </tr>  <tr><td>### This is heading size 3</td> <td>&lt;h3 >This is heading size 3&lt;/h3></td> </tr>  <tr><td>#### This is heading size 4</td> <td>&lt;h4 >This is heading size 4&lt;/h4></td> </tr> </table>

# This is heading size 1

## This is heading size 2

### This is heading size 3

#### This is heading size 4

Paragraph texts are by default aligned justify, images center, headings left, but that can be changed by editing .py file in notepad++.

Custom tag, simple paragraph text:

 <table border=1>  <tr><td>.p Some text</td> <td> &lt;p>Some text&lt;/p></td></tr></table>

.p Some text

Custom paragraph text align center:

 <table border=1>  <tr><td>.pc Some text, centered horizontally</td> <td> &lt;p style="text-align:center !important;">Some text, centered horizontally&lt;/p></td></tr></table>

.pc Some text, centered horizontally (displayed incorrectly in github md to html, but working fine in browsers, or here with align=center ...)

## Typing

&lt;p> will not be added to the text lines which start with space. Newline &lt;br> <b>will</b> be added.

If there are two lines separated with a line that contains only one space, all three lines will be joined into a paragraph. New line (&lt;br>) will be added after each line.

If you want to literally type html tags in text, like &lt;p>, you have to use &amp;lt;p> instead of &lt;p>. Single < is ok. More info here: <a href="https://www.w3schools.com/html/html_entities.asp">https://www.w3schools.com/html/html_entities.asp</a>

For left bracket, that is not part of the &#91;number] use &amp;#91; More info here: <a href="https://www.toptal.com/designers/htmlarrows/punctuation/left-bracket/">https://www.toptal.com/designers/htmlarrows/punctuation/left-bracket/</a>


## Parsing file name

By default parsing 'Test Author - Best Book.txt' will parse author='Test Author' and title='Best Book'. 

Test Author - Series Name 3 - Best Book.txt, will also parse to author='Test Author' and title='Series Name 3 - Best Book'.

 <table border=1>  <tr><td>Test Author - Series Name 3 - Best Book.txt</td> <td>  &lt;head>&lt;meta name="author" content="Test Author"> <br> &lt;title>Series Name - 3 - Best Book&lt;/title>&lt;/head>   </td></tr></table>

## Conversion

press windows + r, enter shell:sendto
it will open "C:\Users\your_user_name\AppData\Roaming\Microsoft\Windows\SendTo"
Copy shortcut to 'convert_simplebook_to_html.bat' there. Drag and drop file, select 'create shortcut here'

To convert txt to html, right click on txt, select send to/'convert_simplebook_to_html.bat -shortcut'

or, drag and drop your .txt file on 'convert_simplebook_to_html.bat' file.

You can also use command line, first line will produce .html file:
(You can also use .html as the source with kindlegen, but it will not create Table of Contents (TOC) accessible from the kindle menu.)
<code>
python "convert_simplebook_to_html.py" "Test Author - Series Name - 3 - Best Book.txt"

kindlegen.exe "Test Author - Series Name - 3 - Best Book.opf" -dont_append_source -o "Test Author - Series Name - 3 - Best Book.mobi"

pandoc.exe "Test Author - Series Name - 3 - Best Book.html" -s -o "Test Author - Series Name - 3 - Best Book.epub"
kindlegen.exe "Test Author - Series Name - 3 - Best Book.epub" -dont_append_source -o "Test Author - Series Name - 3 - Best Book.mobi"

ebook-convert.exe "Test Author - Series Name - 3 - Best Book.html" "Test Author - Series Name - 3 - Best Book.epub"
ebook-convert.exe "Test Author - Series Name - 3 - Best Book.html" "Test Author - Series Name - 3 - Best Book.mobi"
</code>

## Html editors:

-1stPage2000 <a href="https://mega.nz/folder/xGESQQYL#rAlBgQ6QM-FJUhFdXW7Z5g">https://mega.nz/folder/xGESQQYL#rAlBgQ6QM-FJUhFdXW7Z5g</a>
-Seamonkey (Look in menu "windows/composer") <a href="https://www.seamonkey-project.org/">https://www.seamonkey-project.org/</a>

## ebook viewers for pc:

-calibre (ebook-viewer.exe)
-sumatraPDF

## Text editor:

-Notepad++ <a href="https://notepad-plus-plus.org/">https://notepad-plus-plus.org/</a>

If you are reading this on github, this README.md was made by copy pasting html file source from notepad++, and removing prefix text containing styles.

If you are having problems, make sure there are no single spaces at the start of the line. Click on "Show All Characters" in notepad++ (looks like blue reverse P)

## Misc

You can keep filename extension as .md especially if using notepad++, but you probably should not try converting this .md using pandoc.


## Minimal <a href="https://en.wikipedia.org/wiki/EPUB#Open_Packaging_Format_2.0.1">opf</a> and ncx example for kindlegen:

Created from "Best Author - Best Book.txt':

'Best Author - Best Book.opf' content:
 <hr>
&lt;?xml version="1.0"?>

&lt;package>

&emsp;&lt;metadata>
&emsp;&emsp;&lt;dc:title>Best Book&lt;/dc:title>
&emsp;&emsp;&lt;dc:language>en&lt;/dc:language>
&emsp;&emsp;&lt;dc:creator>Best Author&lt;/dc:creator>
&emsp;&lt;/metadata>

&emsp;&lt;manifest>
&emsp;&emsp;&lt;item id="ncx" href="Best Author - Best Book.ncx" media-type="application/xml" />
&emsp;&emsp;&lt;item id="text1" href="Best Author - Best Book.html" media-type="text/html" />
&emsp;&lt;/manifest>

&emsp;&lt;spine toc="ncx">
&emsp;&emsp;&lt;itemref idref="text1" />
&emsp;&lt;/spine>

&lt;/package>
 <hr>

'Best Author - Best Book.ncx' content:
 <hr>
&lt;?xml version="1.0" encoding="UTF-8"?>
&lt;ncx>

&emsp;&lt;navMap>

&emsp;&emsp;&lt;navPoint>
&emsp;&emsp;&emsp;&lt;navLabel>&lt;text>Chapter 1 Title Here&lt;/text>&lt;/navLabel>
&emsp;&emsp;&emsp;&lt;content src="Best Author - Best Book.html#toc1" />
&emsp;&emsp;&lt;/navPoint>

&emsp;&emsp;&lt;navPoint>
&emsp;&emsp;&emsp;&lt;navLabel>&lt;text>Chapter 2 Title Here&lt;/text>&lt;/navLabel>
&emsp;&emsp;&emsp;&lt;content src="Best Author - Best Book.html#toc2" />
&emsp;&emsp;&lt;/navPoint>

&emsp;&lt;/navMap>

&lt;/ncx>
 <hr>
(If you wish, instead of '#toc1' and '#toc2', you can use '#chapter1' and '#chapter2', whatever your chapter anchors are in html file.
Usually, it is 'id' property inside of 'h1' or 'h2' tag at the start of each chapter.
Or a single html or xhtml file for each chapter, like an example at wikipedia: src="chapter1.xhtml".
Single html file is used for the book content, instead of multiple xhtml files.)

## Changes

2024-02-24-1
-added left, center, right align of text (.pl .pc .pr)
-added creating of minimal ncx and opf for kindlegen to mobi, so menu toc is created
-use: kindlegen.exe name.opf, <a href="https://en.wikipedia.org/wiki/EPUB#Open_Packaging_Format_2.0.1">opf example and info</a>
 (for pandoc/calibre to epub use html)
-added 'meta language' tag, because of kindlegen. Use -lang xx to change, default en.
-added command line options, (optional). -h to see them, or look at .py.

2025-02-15-2
-you can set option to add paragraph in front of elements (empty_space)

2025-02-15-1
-bugfixes
-added custom tag, simple paragraph text, when you need to specify one, like for empty paragraph

2025-02-14-1
-added option to use span+br for toc, since it can be surrounded by tag.
 by default div is used, without p tag.

