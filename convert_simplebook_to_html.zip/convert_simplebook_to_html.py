

import re
import os
import sys
import time
start_time = time.time()

from pathlib import Path
try:
	st_input_file=sys.argv[1]
except:
	print('Please pass file name')
	exit()


if not os.path.isfile(st_input_file):
	print('exiting, no file:', st_input_file)
	exit()

#settings
add_custom_prefix_text=1
add_custom_suffix_text=1
prepare_toc=1# remember to add '.t ' at the place of toc, preceded by empty line
warn_about_lines_starting_with_space_containing_text=0
add_html_paragraph_tag_to_unmarked_lines=1 # unless first line preceded by space
heading1=1 #.1 text-> heading 1 text: <h1>text</h1>
heading2=1
heading3=1
heading4=1
img=1 #.i name of image.ext #don't forget space after '.i '. No more text in the same line.
horizontalLine=1# '.* '-> <hr>, or you can just use <hr>, or search and replace *** with <hr>. usually alone in the line
newline=1 #newlines converted to <br>
footnotes=1 #use footnotes[1] '.f1 this is explanation of the footnote'
move_footnotes_to_the_end=1 #end of the book, before aftertext
parse_filename_to_author_filename=1 # parse filename to: author - title
#to add paragraph, set this to '' (except headers, apparently)
#if you do not want to add paragraph around items(img, header, hr, ), and before and after lists(toc, footnotesLow) (but NOT the list items separately) ,set this to ' ', so it will be ignored when adding p
empty_space=''

#custom prefix to the whole text:
custom_prefix_text = ''

#doctype + html tag open
#custom_prefix_text = custom_prefix_text + '<!DOCTYPE html><html>'

#head, used for meta and css style, tag open
custom_prefix_text = custom_prefix_text + '<head>\n'

#text is in utf-8, longer version because of kindlegen
custom_prefix_text = custom_prefix_text + '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">\n'

#parsing author - title to author title
if parse_filename_to_author_filename:
	stJustFilenameNoExtension = Path(st_input_file).stem #file
	if '-' in stJustFilenameNoExtension:
		stAuthor,stTitle = stJustFilenameNoExtension.split('-',1)
		stAuthor = stAuthor.strip()
		stTitle = stTitle.strip()
		#print ('-'+stAuthor+'-','-'+stTitle+'-')
		custom_prefix_text = custom_prefix_text + '<meta name="author" content="' + stAuthor + '">\n'
		custom_prefix_text = custom_prefix_text + '<title>' + stTitle + '</title>\n'#
		#also alternative tag can be used, but shows in html content automatically, cannot disable
		#<dc:title>Superbooks 3 -  My Title </dc:title>

#center headings
custom_prefix_text = custom_prefix_text + '<style>h1,h2,h3,h4 {text-align: center}</style>\n'
#custom_prefix_text = custom_prefix_text + '<style>h1,h2,h3,h4 {text-align: left}</style>'

#custom_prefix_text = custom_prefix_text + '<style>h1,h2,h3,h4 {pageBreakBefore : always}</style>\n'
#does this work? test for footnotes in kindle(gen).

#justify paragraph text
custom_prefix_text = custom_prefix_text + '<style>p {text-align: justify}</style>\n'

#max size for images
custom_prefix_text = custom_prefix_text + '<style>img {max-width: 1080}</style>\n'

#center images
custom_prefix_text = custom_prefix_text + '<style>img {display: block; margin-left: auto; margin-right: auto}</style>\n'

#head, used for meta and css style, tag close
custom_prefix_text = custom_prefix_text + '</head>\n'

#body tag open
custom_prefix_text = custom_prefix_text + '<body>\n'


custom_suffix_text = ''

#body tag close
custom_suffix_text = custom_suffix_text + '</body>\n'

#html tag close
#custom_suffix_text = custom_suffix_text + '</html>\n'


output_file_name_extra_extension=''
finish = ''

liToc=[]
dcBlock = {}
dcSingle = {}
dcWholeTextRegex = {}
dcLowFoot={}

toc = ''#init value for toc list
#add p in front of toc:
#liTcSearchaAndReplace=['<p>.t </p>','<p>','</p>']#search variables, will search '<p>.t </p>' and replace with <p> + toc + </p> later

#do not add p in front of toc:
liTcSearchaAndReplace=['<p>.t </p>','','']#search variables, will search '<p>.t </p>' and replace with <p> + toc + </p> later

#in case you want to add more text at the start and end of toc.
#liTcSearchaAndReplace=['<p>.t </p>','<p>Toc staring: <br>','Toc ends here.</p>']#search '<p>.t </p>', replace with <p> + toc + </p>

tagPara = ['<p>','</p>']#for adding to unmarked lines

### TOC, tag for creating TOC list
tagToc = [' <div style="text-align:left !important"><a href="#toc', '</a></div>']#cannot put div inside p, so no empty space+
#use span + br
#tagToc = [empty_space+'<span><a href="#toc', '</a></span><br>']
if heading1: dcBlock['.1 '] = [' <h1>','</h1>']#empty_space+'<h1>','</h1>'], apparently, you are not supposed to put hx inside p ...
if heading2: dcBlock['.2 '] = [' <h2>','</h2>']
if heading3: dcBlock['.3 '] = [' <h3>','</h3>']
if heading4: dcBlock['.4 '] = [' <h4>','</h4>']

if img: dcBlock['.i '] = [empty_space+'<img src="','">']
if horizontalLine: dcBlock['.* '] = [empty_space+'<hr>','']

#line does not start with this, so no need for space before < ...
if newline: dcSingle['\n'] = '<br>'


if footnotes:#top part of footnotes
	#search something[1]
	#replace with link
	dcWholeTextRegex[r'\[(\d+)\]'] = r'<sup><a id="f\1" href="#fb\1">[\1]</a></sup>'

	#search '.f1 some text in the footnote'
	#replace with helper + footnote + helper. helper needed to stop next line of text appearing in footnotes on kindle, if footnotes are not at the end of the text.
	# one space in front of r' <a ..' so <p is not added to the line later
	# if you want to align them add this: ' style="text-align:justify !important" ' to div, but kindle does not honor alignment of footnotes?
	# could also use span instead of div, but then would have to use <br> after each line. also, there is no possibillity of div appearing inside p here?

	#cannot put div inside p, so not empty_space
	dcLowFoot[r'^\.f(\d+) ((?:.|\n[^\n\n])*)'] = r'<a id="helpertop\1" href="#helperbottom\1"></a>          <div id="fb\1"><a href="#f\1">\1.</a> \2</div>                 <a id="helperbottom\1" href="#helpertop\1"></a>'
	
	#using span, no custom align, cause span is inline element, not block element
	#dcLowFoot[r'^\.f(\d+) ((?:.|\n[^\n\n])*)'] = empty_space+ r'<a id="helpertop\1" href="#helperbottom\1"></a>          <span id="fb\1"><a href="#f\1">\1.</a> \2</span><br>              <a id="helperbottom\1" href="#helpertop\1"></a>'
	#you can also use <p></p> instead of <div></div>, but it does not work in pandoc


#startswith(tuple)


#custom block modifiers:
#space before <p so it is ignored when adding <br>
#should not put p inside p
#cannot put div inside p
dcBlock['.p '] = [' <p>','</p>']#p
dcBlock['.pc '] = [' <p style="text-align:center !important;">','</p>']#p center aligned, for image descriptions
# dcBlock['.1c '] = [' <h1 style="text-align:center !important;">','</h1>']#p center aligned, or uncomment 'center headings' up. images are centered by default.
# dcBlock['.2c '] = [' <h2 style="text-align:center !important;">','</h2>']#p center aligned
# dcBlock['.3c '] = [' <h3 style="text-align:center !important;">','</h3>']#p center aligned
# dcBlock['.4c '] = [' <h4 style="text-align:center !important;">','</h4>']#p center aligned
# dcBlock['.dc '] = [' <div style="text-align:center !important;">','</div>']#div
dcBlock['# '] = [' <h1>','</h1>']
dcBlock['## '] = [' <h2>','</h2>']
dcBlock['### '] = [' <h3>','</h3>']
dcBlock['#### '] = [' <h4>','</h4>']





with open(st_input_file, 'r', encoding="utf-8") as file:
	wholetext = file.read()

	if warn_about_lines_starting_with_space_containing_text:
		arrTestLine = wholetext.split('\n')
		for indT in range (len(arrTestLine)):
			if arrTestLine[indT].startswith(' ') and len(arrTestLine[indT]) > 1:
				print('*** Warning: Text line starts empty space, will not be added paragraph tags ***:', arrTestLine[indT] )

	#footnotes, top part.
	for key,val in dcWholeTextRegex.items():
		wholetext = re.sub(key, val, wholetext, flags=re.MULTILINE)

	#separate on empty lines, denoting future paragraphes
	#also 3 empty lines = 2 \n\n = separator, not 2 \n + 1 \n
	blank_line_regex = r"(?:\r?\n){2,}"
	arrSplit = re.split(blank_line_regex, wholetext.rstrip('\n') )#no strip space, it deletes space after last tag :D
	

	#start with the lines check
	for ind in range (len(arrSplit)):

		for key,val in dcSingle.items():
			if key in arrSplit[ind]:
				arrSplit[ind] = arrSplit[ind].replace(key,val)
			#arrSplit[ind] = re.sub(key, val, arrSplit[ind] )

		#if arrSplit[ind][:1] == '.':#if line starts with '.' messes up custom #

		for key,val in dcLowFoot.items():#bottom part of footnotes
			if re.search( key, arrSplit[ind] ):
				arrSplit[ind] = re.sub(key, val, arrSplit[ind], flags=re.MULTILINE)
				#move footnotes
				#add p once if empty_space missing
				if move_footnotes_to_the_end:
					if empty_space == '' and move_footnotes_to_the_end == 1:#add p, if there is no space before tags, once
						arrSplit.append(tagPara[0] + tagPara[1])
						move_footnotes_to_the_end = 2
					arrSplit.append(arrSplit[ind])
					arrSplit[ind] = ' '# not .pop cause index increases.

		for key,val in dcBlock.items():
			if arrSplit[ind].startswith(key):

				#print('-'+key+'-')
				text=arrSplit[ind].replace(key,'',1)#replace once, cause it is at the start

				#headings, add id, so we can create toc. If it is needed later.
				if val[1].startswith('</h') and prepare_toc:
					#<h2 id="C4">Chapter 4</h2>
					tocCounter = len(liToc)+1#list will be empty, so toc counter =1; then list will have one element, toc counter =2 ...
					custom=' id="toc'+str(tocCounter)+'">' #another option is to use <span > tag with id inside, if headings ids are not to be added.
					arrSplit[ind] = val[0].replace('>',custom)+text+val[1]

					#<a href="#c1">jump to Chapter 4</a>
					#cannot align just <a href><br> to left, so using div
					liToc.append(tagToc[0] + str(tocCounter)+'">- '+text+ tagToc[1])
				else:
					arrSplit[ind] = val[0]+text+val[1]
				#print(arrSplit[ind])
				#arrSplit[ind] = 

		#if it does not start with ' ', add paragraph around it:
		if  arrSplit[ind][:1] != ' '   and add_html_paragraph_tag_to_unmarked_lines:
			arrSplit[ind] = tagPara[0] + arrSplit[ind] + tagPara[1]

		#finish = finish + arrSplit[ind] + '\n' #groups start with 1

	#after all is done, add toc in place of its holder '.t '

	if prepare_toc and liToc:
		toc = '\n'.join(liToc)

		if empty_space == '':#surrond toc with p, if empty_space is missing
			toc = tagPara[0]+tagPara[1] + toc + tagPara[0]+tagPara[1]#cause you cant put div inside p, but you can add p/p before and after

		for ind in range (len(arrSplit)):
			if arrSplit[ind].startswith(liTcSearchaAndReplace[0]):#'<p>.t </p>'; cause <p> was already added
				arrSplit[ind]=arrSplit[ind].replace(liTcSearchaAndReplace[0],  liTcSearchaAndReplace[1] + toc + liTcSearchaAndReplace[2], 1 )#replace once
				##'<p>.t </p>', <p> + toc + </p>; replace once, cause it is at the start, to remove <p> around toc use: replace('<p>.t </p>',toc,1)


		#arrSplit[ind] = arrSplit[ind].replace(key,val[0],1)+val[1]#replace once, cause it is at the start	
	#finish=finish.replace('.t ','\n'.join(liToc))

	#finish = re.sub( liTcSearchaAndReplace[0],  liTcSearchaAndReplace[1] + toc + liTcSearchaAndReplace[2],  finish,  flags=re.MULTILINE )#'<p>.t </p>', <p> + toc + </p>
	#multiline

finish = '\n'.join(arrSplit)

if add_custom_prefix_text: finish = custom_prefix_text + finish

if add_custom_suffix_text: finish = finish + custom_suffix_text

if '.' in st_input_file:
	st_input_file = st_input_file.rsplit('.', 1)[0]#split once from the right, first item is STILL first from the LEFT

outfile = st_input_file + output_file_name_extra_extension+'.html'
with open(outfile, "w", encoding="utf-8") as fileo:
	fileo.write(finish)

print('finished, ',"--- %.5f seconds ---" % (time.time() - start_time))


r'''

conversion for textile, using notepad++ regex:

replace !pic.jpg! with '.i pic.jpg '
^(\!)(.*?)(\!)
.i \2

#mind the space after \1 .*
replace 'h1. ' -> '.1 '
^h(\d). 
.\1 


replace *** with '.* '
^\*\*\*$
.* 


'[1]'
#\[\d+\]


replace 'fn1. ' with '.f1 '
^fn(\d+)\. 
\.f\1 

'''